import { Component } from '@angular/core';

@Component({
  selector: 'user',
  template: `
    <h2>User Information </h2>
    <p>
    Name: {{name}}<br />
    Email: {{email}}<br />
    Phone: {{phone}}<br />
    Address: {{address.street}}, {{address.house}}, {{address.city}}, {{address.state}} 
    </p>
    <button (click)='toggleHobbies()'>{{showHobbies ? "Hide Hobbies" : "Show Hobbies"}}</button>
    <div *ngIf="showHobbies">
    <h3>Hobbies:</h3>
    <ul>
       <li *ngFor="let hobby of hobbies">
            {{hobby}}
       </li>
    </ul>
    </div>
    <hr />
      <form>
        <label>Name: </label>
        <input type="text" name="name" [(ngModel)]="name" /><br />
        <label>Email: </label>
        <input type="text" name="email" [(ngModel)]="email" /><br />
        <label>Phone: </label>
        <input type="text" name="phone" [(ngModel)]="phone" /><br />
        <label>Street: </label>
        <input type="text" name="address.street" [(ngModel)]="address.street" /><br />
        <label>House: </label>
        <input type="text" name="address.house" [(ngModel)]="address.house" /><br />
        <label>City: </label>
        <input type="text" name="address.city" [(ngModel)]="address.city" /><br />
        <label>State: </label>
        <input type="text" name="address.state" [(ngModel)]="address.state" /><br />
    </form>
      <hr />
      `,
})
export class UserComponent {
   name: string;
   email: string;
   phone: string; 
   address: address;
   showHobbies: boolean;

   constructor(){
    this.name = 'John Mia';
    this.email = 'john@gmail.com'
    this.phone = '01713041788'
    this.address = {
            street: '123 link face area',
            house: 'Ja-722 Term Center',
            city: 'Dhaka',
            state: "Bangladesh",
        } 
        this.hobbies = ['Music', 'Games', 'Hunt', 'Race'];
        this.showHobbies = false;
    }

    toggleHobbies(){
        if(this.showHobbies == true){
            this.showHobbies = false;
        } else{
            this.showHobbies = true;
        }
    }

}
interface address{
    street: string;
    house: string;
    city: string;
    state: string;
}