import { Component } from '@angular/core';

@Component({
  selector: 'user',
  template: `
    <div class="container">
        <div class="jumbotron">
            <h2>User Information </h2>
            <p>
            Name: {{name}}<br />
            Email: {{email}}<br />
            Phone: {{phone}}<br />
            Address: {{address.street}}, {{address.house}}, {{address.city}}, {{address.state}} 
            </p>
            </div>
    <button (click)='toggleHobbies()'>{{showHobbies ? "Hide Hobbies" : "Show Hobbies"}}</button>
    <div *ngIf="showHobbies">
    <h3>Hobbies:</h3>
    <ul>
       <li *ngFor="let hobby of hobbies; let i = index">
            {{hobby}} <button (click)="deleteHobby(i)">Delete</button>
       </li>
    </ul>
    <form (submit)="addHobby(hobby.value)"> 
        <label>Add More Hobby</label><br />
        <input type="text" #hobby />
    </form>
    </div>
    <hr />
    <div class="panel panel-primary">
        <div class="panel-heading">
        <strong>Want to Edit?</strong>
        </div>  
        <div class="panel panel-body">
                <form>
                <div class="form-group">
                    <label>Name: </label>
                    <input class="form-control" type="text" name="name" [(ngModel)]="name" />
                    <label>Email: </label>
                    <input class="form-control" type="text" name="email" [(ngModel)]="email" />
                    <label>Phone: </label>
                    <input class="form-control" type="text" name="phone" [(ngModel)]="phone" />
                    <label>Street: </label>
                    <input class="form-control" type="text" name="address.street" [(ngModel)]="address.street" />
                    <label>House: </label>
                    <input class="form-control" type="text" name="address.house" [(ngModel)]="address.house" />
                    <label>City: </label>
                    <input class="form-control" type="text" name="address.city" [(ngModel)]="address.city" />
                    <label>State: </label>
                    <input class="form-control" type="text" name="address.state" [(ngModel)]="address.state" />
                </div>
                </form>
        </div>
        </div>
      </div>
      `,
})
export class UserComponent {
   name: string;
   email: string;
   phone: string; 
   address: address;
   showHobbies: boolean;

   constructor(){
    this.name = 'John Mia';
    this.email = 'john@gmail.com'
    this.phone = '01713041788'
    this.address = {
            street: '123 link face area',
            house: 'Ja-722 Term Center',
            city: 'Dhaka',
            state: "Bangladesh",
        } 
        this.hobbies = ['Music', 'Games', 'Hunt', 'Race'];
        this.showHobbies = false;
    }

    toggleHobbies(){
        if(this.showHobbies == true){
            this.showHobbies = false;
        } else{
            this.showHobbies = true;
        }
    }
addHobby(hobby){
    this.hobbies.push(hobby);
}
deleteHobby(i){
    this.hobbies.splice(i, 1);
}
}
interface address{
    street: string;
    house: string;
    city: string;
    state: string;
}