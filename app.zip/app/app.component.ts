import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <user></user>
    `,
})
export class AppComponent {
    
}